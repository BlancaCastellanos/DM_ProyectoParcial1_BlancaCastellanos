//
//  ViewController.swift
//  ProyectoPrimerParcial
//
//  Created by Alumno on 9/14/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var playerFondo = AVAudioPlayer()
    var playerAnimal = AVAudioPlayer()
    
    let urlFondo = Bundle.main.url(forResource: "MusicaFondo", withExtension: "mp3")
    let urlGato = Bundle.main.url(forResource: "GATO", withExtension: "mp3")
    let urlPajaro = Bundle.main.url(forResource: "PAJARO", withExtension: "mp3")
    let urlPerro = Bundle.main.url(forResource: "PERRO", withExtension: "mp3")


        let AnimacionGato2 = [
            UIImage(named: "GATO 2 (1)")!,
            UIImage(named: "GATO 2 (2)")!,
            UIImage(named: "GATO 2 (3)")!,
            UIImage(named: "GATO 2 (4)")!,
            UIImage(named: "GATO 2 (5)")!,
        ]
    
        let AnimacionPajaro2 = [
            UIImage(named: "Pajaro1")!,
            UIImage(named: "Pajaro2")!,
            UIImage(named: "Pajaro3")!,
            UIImage(named: "Pajaro4")!,
            UIImage(named: "Pajaro5")!,
        ]
        
        let AnimacionPerro2 = [
            UIImage(named: "PERRO 1 (1)")!,
            UIImage(named: "PERRO 1 (2)")!,
            UIImage(named: "PERRO 1 (3)")!,
            UIImage(named: "PERRO 1 (4)")!,
            UIImage(named: "PERRO 1 (5)")!,
        ]
    
        let AnimacionGato1 = [
            UIImage(named: "GATO 1 (1)")!,
            UIImage(named: "GATO 1 (2)")!,
            UIImage(named: "GATO 1 (3)")!,
            UIImage(named: "GATO 1 (4)")!,
            UIImage(named: "GATO 1 (5)")!,
        ]
    
        let AnimacionPajaro1 = [
            UIImage(named: "1")!,
            UIImage(named: "2")!,
            UIImage(named: "3")!,
            UIImage(named: "4")!,
            UIImage(named: "5")!,
        ]
        
        let AnimacionPerro1 = [
            UIImage(named: "PERRO 2 (1)")!,
            UIImage(named: "PERRO 2 (2)")!,
            UIImage(named: "PERRO 2 (3)")!,
            UIImage(named: "PERRO 2 (4)")!,
            UIImage(named: "PERRO 2 (5)")!,
        ]
    
    
    //OUTLETS
    @IBOutlet weak var imgGato2: UIImageView!
    @IBOutlet weak var imgPajaro2: UIImageView!
    @IBOutlet weak var imgPerro2: UIImageView!
    @IBOutlet weak var imgGeneral: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
        //Inicializar los players
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            playerFondo = try AVAudioPlayer(contentsOf: urlFondo!, fileTypeHint: AVFileType.mp3.rawValue)
            playerFondo.numberOfLoops = -1
            playerFondo.volume = 0.2
            
            playerFondo.play()
        }
        
        
        catch let error {
            print(error.localizedDescription)
        }
    }
     
    
    //ACTIONS
    @IBAction func DoTapAnimarGato2(_ sender: Any) {
        
        do{
            playerAnimal = try AVAudioPlayer(contentsOf: urlGato!, fileTypeHint: AVFileType.mp3.rawValue)
            playerAnimal.play()
        } catch let error {
            print(error.localizedDescription)
        }
        
        imgGato2.animationImages = AnimacionGato2
        imgGato2.animationDuration = 1.5
        imgGato2.startAnimating()
        
        imgGeneral.animationImages = AnimacionGato1
        imgGeneral.animationDuration = 3.0
        imgGeneral.startAnimating()
    }
    
    
    @IBAction func DoTapAnimarPajarito2(_ sender: Any) {
        
        do{
            playerAnimal = try AVAudioPlayer(contentsOf: urlPajaro!, fileTypeHint: AVFileType.mp3.rawValue)
            playerAnimal.play()
        } catch let error {
            print(error.localizedDescription)
        }
        
        
        imgPajaro2.animationImages = AnimacionPajaro2
        imgPajaro2.animationDuration = 1.5
        imgPajaro2.startAnimating()
        
        imgGeneral.animationImages = AnimacionPajaro1
        imgGeneral.animationDuration = 1.5
        imgGeneral.startAnimating()
    }
    
    
    @IBAction func DoTapAnimarPerro2(_ sender: Any) {
        
        do{
            playerAnimal = try AVAudioPlayer(contentsOf: urlPerro!, fileTypeHint: AVFileType.mp3.rawValue)
            playerAnimal.play()
        } catch let error {
            print(error.localizedDescription)
        }
        
        imgPerro2.animationImages = AnimacionPerro2
        imgPerro2.animationDuration = 1.5
        imgPerro2.startAnimating()
        
        imgGeneral.animationImages = AnimacionPerro1
        imgGeneral.animationDuration = 3.0
        imgGeneral.startAnimating()
        
    }
}
